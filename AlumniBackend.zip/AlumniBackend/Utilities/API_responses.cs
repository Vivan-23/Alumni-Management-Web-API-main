﻿using AlumniBackend.Utilities;

namespace AlumniBackend.Utilities
{
    public class ApiResponse<T>
    {
        public bool success { get; init; }
        public T? data { get; init; }
        public string message { get; init; } = string.Empty;
        public string? traceId { get; init; }
        public IEnumerable<String?>? errors { get; init; }
        private ApiResponse() { }
        public static ApiResponse<T> Success(T? data, string message, string? traceId)
        => new(){
            success = true,
            message = message,
            traceId = traceId,
            data = data 
        };  

        public static ApiResponse<T> Failed(T? data, string message, string? traceId)
            => new()
            {
                message = message,
                data = data,
                traceId = traceId,
                success = false
            };
    }
}
//public bool Success { get; init; }
//public string Message { get; init; } = string.Empty;
//public T? Data { get; init; }
//public string? TraceId { get; init; }
//public IEnumerable<string>? Errors { get; init; }

//private ApiResponse() { }

//public static ApiResponse<T> Ok(T data, string message, string? traceId = null)
//    => new()
//    {
//        Success = true,
//        Message = message,
//        Data = data,
//        TraceId = traceId
//    };

//public static ApiResponse<T> Fail(
//    string message,
//    IEnumerable<string>? errors = null,
//    string? traceId = null
//)
//    => new()
//    {
//        Success = false,
//        Message = message,
//        Errors = errors,
//        TraceId = traceId
//    };