﻿using System.ComponentModel.DataAnnotations;

namespace AlumniBackend.Models
{
    //public class Events
    //{
    //    [Key]
    //    public int? EventsId { get; set; }
    //    public string EventName { get; set; }
    //    public string? EventDescription { get; set; }
    //    public TimeSpan  EventTime { get; set; }
    //    public DateOnly EventDate { get; set; }
    //    public string EventLocation { get; set; }
    //    public string CreatedBy { get; set; }
    //    public ICollection<EventRegistration> EventRegistration { get; set; }

    //}
    public class Events
    {
        [Key]
        public int EventsId { get; set; }

        [Required]
        public string EventName { get; set; }

        public string? EventDescription { get; set; }
        public TimeSpan EventTime { get; set; }
        public DateOnly EventDate { get; set; }

        public string EventLocation { get; set; }
        public string CreatedBy { get; set; }

        public ICollection<EventRegistration> EventRegistration { get; set; }
    }

}
