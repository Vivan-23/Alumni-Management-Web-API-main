﻿using System.ComponentModel.DataAnnotations;

namespace AlumniBackend.Models
{
    //public class User
    //{

    //    public string UserName { get; set; }
    //    public string Passwordhash { get; set; }
    //    [Required]
    //    [EmailAddress]
    //    public string Email { get; set; }
    //    [DataType(DataType.PhoneNumber)]
    //    public string Phone { get; set; }
    //    [Key]
    //    public int? UserId { get; set; }
    //    public DateTime? CreatedDate { get; set; }
    //    = DateTime.Now;
    //    public int RoleId { get; set; } = 1;
    //    public Roles Role { get; set; }

    //    public bool IsFirstLogin { get; set; } = true;
    //    public ICollection<AlumniProfile> AlumniProfile { get; set; }
    //}
    public class User
    {
        [Key]
        public int UserId { get; set; }

        public string UserName { get; set; }
        public string Passwordhash { get; set; }

        [Required, EmailAddress]
        public string Email { get; set; }

        public string Phone { get; set; }

        public DateTime CreatedDate { get; set; } = DateTime.Now;

        public int RoleId { get; set; }
        public Roles Role { get; set; }

        public bool IsFirstLogin { get; set; } = true;

        public ICollection<AlumniProfile> AlumniProfile { get; set; }
        public ICollection<Donation> Donation { get; set; }
    }

}
