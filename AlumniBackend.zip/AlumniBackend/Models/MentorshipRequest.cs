﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AlumniBackend.Models
{
    //public class MentorshipRequest
    //{
    //    public enum status
    //    {
    //        Approved,
    //        Not_Approved,
    //        pending
    //    }
    //    [Key]
    //    public int? RequestId { get; set; }
    //    public int? AlumniId { get; set; }
    //    public int UserId { get; set; } //role student
    //    public DateTime CreatedDate { get; set; } = DateTime.Now;
    //    public status Status { get; set; }
    //    [ForeignKey(nameof(AlumniId))]
    //    public AlumniProfile? AlumniProfile { get; set; }
    //}
    public class MentorshipRequest
    {
        [Key]
        public int RequestId { get; set; }

        public int AlumniId { get; set; }
        public int UserId { get; set; }

        public DateTime CreatedDate { get; set; } = DateTime.Now;

        public status Status { get; set; }

        public AlumniProfile AlumniProfile { get; set; }

        public enum status
        {
            Approved,
            Not_Approved,
            Pending
        }
    }

}
