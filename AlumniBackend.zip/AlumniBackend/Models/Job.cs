﻿using System.ComponentModel.DataAnnotations;

namespace AlumniBackend.Models
{
    //public class Job
    //{
    //    public int JobId { get; set; }
    //    public string Title { get; set; }
    //    public string Description { get; set; }
    //    public string Company { get; set; }
    //    public string Location { get; set; }
    //    public DateTime PostedDate { get; set; } = DateTime.Now;
    //    public DateTime? ExpiryDate { get; set; }
    //    public string? ApplyLink { get; set; }
    //    public int AlumniId { get; set; }
    //    public AlumniProfile? Alumni { get; set; }
    //    public ICollection<Job> Jobs { get; set; }

    //}
    public class Job
    {
        [Key]
        public int JobId { get; set; }

        [Required]
        public string Title { get; set; }

        public string Description { get; set; }
        public string Company { get; set; }

        public DateTime PostedDate { get; set; } = DateTime.Now;
        public DateTime? ExpiryDate { get; set; }
        public string? ApplyLink { get; set; }

        // FK
        public int AlumniId { get; set; }

        // Navigation
        public AlumniProfile Alumni { get; set; }
    }

}
