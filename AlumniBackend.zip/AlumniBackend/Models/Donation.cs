﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AlumniBackend.Models
{
    //public class Donation
    //{
    //    [Key]
    //    public int? DonationId { get; set; }
    //    public string Description { get; set; }
    //    [Required]
    //    public int AlumniId { get; set; }
    //    public double Amount { get; set; }
    //    [ForeignKey(nameof(AlumniId))]
    //    public AlumniProfile Alumni { get; set; }
    //}
    public class Donation
    {
        [Key]
        public int DonationId { get; set; }

        public int AlumniId { get; set; }
        public int UserId { get; set; }

        public double Amount { get; set; }
        public string Description { get; set; }

        public AlumniProfile Alumni { get; set; }
        public User User { get; set; }
    }

}
