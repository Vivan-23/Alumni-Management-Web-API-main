﻿using System.ComponentModel.DataAnnotations;

namespace AlumniBackend.Models
{

    //public class AlumniProfile
    //{
    //    [Key]
    //    public int AlumniId { get; set; }  // Primary Key

    //    public string? CompanyName { get; set; }
    //    public string? Designation { get; set; }
    //    public string? linkedinurl { get; set; }
    //    [Required]
    //    public string AlumniName { get; set; }
    //    [Required]
    //    public string Passout_year { get; set; }

    //    // Foreign Key to User
    //    public int UserId { get; set; }
    //    public User User { get; set; }

    //    // Navigation Properties
    //    public ICollection<EventRegistration> EventRegistration { get; set; }
    //    public ICollection<Donation> Donation { get; set; }
    //    public ICollection<MentorshipRequest> MentorshipRequest { get; set; }
    //    public ICollection<Job> Jobs { get; set; }
    //}
    public class AlumniProfile
    {
        [Key]
        public int AlumniId { get; set; }

        [Required]
        public string AlumniName { get; set; }

        [Required]
        public string Passout_year { get; set; }

        public string? CompanyName { get; set; }
        public string? Designation { get; set; }
        public string? linkedinurl { get; set; }

        // FK
        public int UserId { get; set; }

        // Navigation
        public User User { get; set; }

        public ICollection<EventRegistration> EventRegistration { get; set; }
        public ICollection<Donation> Donation { get; set; }
        public ICollection<MentorshipRequest> MentorshipRequest { get; set; }
        public ICollection<Job> Job { get; set; }
    }
    
}
