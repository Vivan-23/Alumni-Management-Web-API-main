﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AlumniBackend.Models
{
    //public class EventRegistration
    //{
    //    public enum status
    //    {
    //        yes,
    //        no,
    //        unsure

    //    }
    //    [Key]
    //    public int? RegistrationId { get; set; }
    //    public int EventId { get; set; }
    //    public int AlumniId { get; set; }

    //    [ForeignKey(nameof(AlumniId))]
    //    public AlumniProfile AlumniProfile { get; set; }
    //    public status Status { get; set; }
    //    [ForeignKey(nameof(EventId))]
    //    public Events Events { get; set; }

    //}
    public class EventRegistration
    {
        [Key]
        public int RegistrationId { get; set; }

        public int EventId { get; set; }
        public int AlumniId { get; set; }

        public Events Event { get; set; }
        public AlumniProfile AlumniProfile { get; set; }

        public status Status { get; set; }

        public enum status
        {
            yes,
            no,
            unsure
        }
    }

}
