﻿using AlumniBackend.Models;
using Microsoft.EntityFrameworkCore;

namespace AlumniBackend.DATA

{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }
        public DbSet<User> Users { get; set; }
        public DbSet<Events> Events { get; set; }
        public DbSet<EventRegistration> EventRegistrations { get; set; }
        public DbSet<AlumniProfile> AlumniProfiles { get; set; }
        public DbSet<MentorshipRequest> MentorshipRequests { get; set; }
        public DbSet<Donation> Donations { get; set; }
        public DbSet<Roles> Roles { get; set; }
        public DbSet<Job> Job { get; set; }



        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            // USER
            modelBuilder.Entity<User>(entity =>
            {
                entity.ToTable("Users");

                entity.HasKey(e => e.UserId);

                entity.Property(e => e.UserName)
                      .HasColumnType("nvarchar(100)")
                      .IsRequired();

                entity.Property(e => e.Email)
                      .HasColumnType("nvarchar(255)")
                      .IsRequired();

                entity.Property(e => e.Phone)
                      .HasColumnType("nvarchar(15)");

                entity.Property(e => e.Passwordhash)
                      .HasColumnType("nvarchar(max)")
                      .IsRequired();

                entity.Property(e => e.CreatedDate)
                      .HasDefaultValueSql("GETDATE()");

                entity.HasOne(e => e.Role)
                      .WithMany(r => r.User)
                      .HasForeignKey(e => e.RoleId)
                      .OnDelete(DeleteBehavior.Restrict);
            });
            // ROLES
            modelBuilder.Entity<Roles>(entity =>
            {
                entity.ToTable("Roles");

                entity.HasKey(e => e.RoleId);

                entity.Property(e => e.RoleName)
                      .HasColumnType("nvarchar(50)")
                      .IsRequired();
            });
            // ALUMNI PROFILE
            modelBuilder.Entity<AlumniProfile>(entity =>
            {
                entity.ToTable("AlumniProfiles");

                entity.HasKey(e => e.AlumniId);

                entity.Property(e => e.AlumniName)
                      .HasColumnType("nvarchar(200)")
                      .IsRequired();

                entity.Property(e => e.CompanyName)
                      .HasColumnType("nvarchar(200)");

                entity.Property(e => e.Designation)
                      .HasColumnType("nvarchar(100)");

                entity.Property(e => e.Passout_year)
                      .HasColumnType("nvarchar(10)")
                      .IsRequired();

                entity.Property(e => e.linkedinurl)
                      .HasColumnType("nvarchar(255)");

                entity.HasOne(e => e.User)
                      .WithMany(u => u.AlumniProfile)
                      .HasForeignKey(e => e.UserId)
                      .OnDelete(DeleteBehavior.Cascade);
            });
            // EVENTS
            modelBuilder.Entity<Events>(entity =>
            {
                entity.ToTable("Events");

                entity.HasKey(e => e.EventsId);

                entity.Property(e => e.EventName)
                      .HasColumnType("nvarchar(200)")
                      .IsRequired();

                entity.Property(e => e.EventDescription)
                      .HasColumnType("nvarchar(max)");

                entity.Property(e => e.EventLocation)
                      .HasColumnType("nvarchar(255)");

                entity.Property(e => e.CreatedBy)
                      .HasColumnType("nvarchar(100)")
                      .IsRequired();

                entity.Property(e => e.EventDate)
                      .HasColumnType("date")
                      .IsRequired();

                entity.Property(e => e.EventTime)
                      .HasColumnType("time")
                      .IsRequired();
            });
            // EVENT REGISTRATION
            modelBuilder.Entity<EventRegistration>(entity =>
            {
                entity.ToTable("EventRegistrations");

                entity.HasKey(e => e.RegistrationId);

                entity.Property(e => e.Status)
                      .HasConversion<string>()
                      .IsRequired();

                entity.HasOne(e => e.AlumniProfile)
                      .WithMany(a => a.EventRegistration)
                      .HasForeignKey(e => e.AlumniId)
                      .OnDelete(DeleteBehavior.Cascade);

                entity.HasOne(e => e.Event)
                      .WithMany(ev => ev.EventRegistration)
                      .HasForeignKey(e => e.EventId)
                      .OnDelete(DeleteBehavior.Cascade);

                entity.HasIndex(e => new { e.AlumniId, e.EventId })
                      .IsUnique();
            });
            // JOBS
            modelBuilder.Entity<Job>(entity =>
            {
                entity.ToTable("Job");

                entity.HasKey(e => e.JobId);

                entity.Property(e => e.Title)
                      .HasColumnType("nvarchar(200)")
                      .IsRequired();

                entity.Property(e => e.Company)
                      .HasColumnType("nvarchar(200)")
                      .IsRequired();

                entity.Property(e => e.Description)
                      .HasColumnType("nvarchar(max)");

                entity.Property(e => e.PostedDate)
                      .IsRequired();

                entity.Property(e => e.ExpiryDate)
                      .IsRequired(false);

                entity.Property(e => e.ApplyLink)
                      .HasColumnType("nvarchar(255)");

                entity.HasOne(e => e.Alumni)
                      .WithMany(a => a.Job)
                      .HasForeignKey(e => e.AlumniId)
                      .OnDelete(DeleteBehavior.Cascade);
            });
            // MENTORSHIP REQUEST
            modelBuilder.Entity<MentorshipRequest>(entity =>
            {
                entity.ToTable("MentorshipRequests");

                entity.HasKey(e => e.RequestId);

                entity.Property(e => e.CreatedDate)
                      .IsRequired();

                entity.Property(e => e.Status)
                      .HasConversion<int>()
                      .IsRequired();

                entity.HasOne(e => e.AlumniProfile)
                      .WithMany(a => a.MentorshipRequest)
                      .HasForeignKey(e => e.AlumniId)
                      .OnDelete(DeleteBehavior.Cascade);
            });
            // DONATIONS
            modelBuilder.Entity<Donation>(entity =>
            {
                entity.ToTable("Donations");

                entity.HasKey(e => e.DonationId);

                entity.Property(e => e.Amount)
                      .IsRequired();

                entity.Property(e => e.Description)
                      .HasColumnType("nvarchar(max)")
                      .IsRequired();

                entity.HasOne(e => e.Alumni)
                      .WithMany(a => a.Donation)
                      .HasForeignKey(e => e.AlumniId)
                      .OnDelete(DeleteBehavior.Cascade);

                entity.HasOne(e => e.User)
                      .WithMany()
                      .HasForeignKey(e => e.UserId)
                      .OnDelete(DeleteBehavior.Cascade);

            });
        }

    }
}
