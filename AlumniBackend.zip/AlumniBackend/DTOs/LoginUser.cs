﻿namespace AlumniBackend.DTOs
{
    public class LoginUser
    {
        public string UserName { get; set; }
        public string Passwordhash { get; set; }
    }
}
