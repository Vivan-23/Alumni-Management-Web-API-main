﻿namespace AlumniBackend.DTOs
{
    public class JobList
    {
        public string Company { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime PostedDate { get; set; }
        public DateTime? ExpiryDate { get; set; }
        public string? ApplyLink { get; set; }
    }
}
