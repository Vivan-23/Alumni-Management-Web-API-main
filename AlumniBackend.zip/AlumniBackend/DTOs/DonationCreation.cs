﻿using AlumniBackend.Models;
using System.ComponentModel.DataAnnotations;

namespace AlumniBackend.DTOs
{
    
    public class DonationCreation
    {
        

        public double Amount { get; set; }
        public string Description { get; set; }

    }
}
