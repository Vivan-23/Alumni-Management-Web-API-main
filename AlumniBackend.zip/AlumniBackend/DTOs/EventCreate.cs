﻿namespace AlumniBackend.DTOs
{
    public class EventCreate
    {
        
        public string EventName { get; set; }
        public string? EventDescription { get; set; }
        public TimeSpan EventTime { get; set; }
        public DateOnly EventDate { get; set; }
        public string EventLocation { get; set; }
    }
}
