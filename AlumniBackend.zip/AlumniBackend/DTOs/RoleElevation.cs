﻿namespace AlumniBackend.DTOs
{
    public class RoleElevation
    {
        
        public required string UserName { get; set; }
        public required string  Role { get; set; }
    }
}
