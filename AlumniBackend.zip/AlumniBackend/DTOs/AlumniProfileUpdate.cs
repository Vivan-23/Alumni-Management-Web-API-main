﻿namespace AlumniBackend.DTOs
{
    public class AlumniProfileUpdate
    {
        
        public string? CompanyName { get; set; }
        public string? Designation { get; set; }
        public string? linkedinurl { get; set; }
        public string AlumniName { get; set; }
        public string Passout_year { get; set; }
        
    }
}
