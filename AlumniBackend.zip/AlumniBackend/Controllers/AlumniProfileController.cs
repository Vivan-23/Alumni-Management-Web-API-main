﻿using AlumniBackend.DATA;
using AlumniBackend.DTOs;
using AlumniBackend.Models;
using AlumniBackend.Utilities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using AlumniBackend.Services;
namespace AlumniBackend.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AlumniProfileController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly ILogger<AlumniProfileController> _logger;
        private readonly AlumniProfileService _alumniProfileService;
        public AlumniProfileController(AppDbContext context, ILogger<AlumniProfileController> logger, AlumniProfileService alumniProfileService)
        {
            _context = context;
            _logger = logger;
            _alumniProfileService = alumniProfileService;
        }

        [Authorize] 
        [HttpPost("Update")]
        public async Task<IActionResult> UpdateAlumniInfo([FromBody] AlumniProfileUpdate info)
        {
            if (info == null || string.IsNullOrEmpty(info.AlumniName) || info.Passout_year == null)
                return BadRequest(ApiResponse<object>.Failed(null, "Enter valid info", HttpContext.TraceIdentifier.ToString()));

            var userName = User.FindFirst("UserName")?.Value;
            if (string.IsNullOrEmpty(userName))
                return Unauthorized(ApiResponse<object>.Failed(null, "UserName missing in token",HttpContext.TraceIdentifier.ToString()));

            var existing = await _alumniProfileService.UpdateProfileAsync(info, userName);
            if (existing == null) return NotFound(ApiResponse<object>.Failed(null, "Alumni profile not found", HttpContext.TraceIdentifier.ToString()));
            return Ok(ApiResponse<AlumniProfileUpdate>.Success(existing, "Alumni profile saved/updated successfully", HttpContext.TraceIdentifier.ToString()));

        }

        [Authorize]
        [HttpGet("GetAlumni")]
        public async Task<IActionResult> GetAlumniInfoAsync()
        {
            var userName = User.FindFirst("UserName")?.Value;
            if (string.IsNullOrEmpty(userName))
                return Unauthorized(ApiResponse<object>.Failed(null, "UserName missing in token", HttpContext.TraceIdentifier.ToString()));

            
            
            var res = await _alumniProfileService.AlumniinfoAync(userName);
            if (res == null) return NotFound(ApiResponse<object>.Failed(null, "Alumni profile not found", HttpContext.TraceIdentifier.ToString()));
            
            return Ok(ApiResponse<object>.Success(res, "", HttpContext.TraceIdentifier.ToString()));
        }
        [Authorize]
        [HttpGet("GetAllAlumni")]
        public async Task<IActionResult> GetAllAlumniAsync()
        {
            var alumnilist = await _context.AlumniProfiles.Select(a => new
            {
                a.AlumniId,
                a.AlumniName,
                a.CompanyName,
                a.Designation,
                a.Passout_year,
                a.linkedinurl,
                a.User.UserName,
                a.User.Email,
                a.User.Phone
            }).ToListAsync();
            return Ok(ApiResponse<object>.Success(alumnilist, "Alumni List ", HttpContext.TraceIdentifier.ToString()));
        }
    }
}
