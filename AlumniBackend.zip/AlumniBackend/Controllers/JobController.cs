﻿using AlumniBackend.DATA;
using AlumniBackend.DTOs;
using AlumniBackend.Models;
using AlumniBackend.Services;
using AlumniBackend.Utilities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AlumniBackend.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class JobController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly JobService _jobService;
        private readonly EventsRegistrationService _eventsRegistrationService;

        public JobController(AppDbContext context, JobService jobService, EventsRegistrationService eventsRegistrationService)
        {
            _context = context;
            _jobService = jobService;
            _eventsRegistrationService = eventsRegistrationService;
        }
        [Authorize]
        [HttpPost("CreateJobDescr")]
        public async Task<IActionResult> CreateJobAsync(JobList job)
        {
            if (job == null) return BadRequest(ApiResponse<object>.Failed(null,"Job details missing" , HttpContext.TraceIdentifier.ToString()));
            var exists = await _jobService.JobExistsAsync(job.Title, job.Company);
            if (exists) return BadRequest(ApiResponse<object>.Failed(null, "Job already exists", HttpContext.TraceIdentifier.ToString()));
            var userNameClaim = User.FindFirst("UserName")?.Value;
            if (string.IsNullOrEmpty(userNameClaim)) return Unauthorized(ApiResponse<object>.Failed(null,"UserName missing in token", HttpContext.TraceIdentifier.ToString()));
            var alumniId = await _eventsRegistrationService.GetAlumniIdAsync(userNameClaim);
            var jobEntity = new Job
            {
                Title = job.Title,
                Description = job.Description,
                Company = job.Company,
                PostedDate = job.PostedDate,
                ExpiryDate = job.ExpiryDate,
                ApplyLink = job.ApplyLink,
                AlumniId = alumniId
            };

            await _context.Job.AddAsync(jobEntity);
            return Ok(ApiResponse<object>.Success(null, "Job created successfully", HttpContext.TraceIdentifier.ToString()));
        }
        [Authorize]
        [HttpGet("GetAllJobPostings")]
        public async Task<IActionResult> GetAllJobsAsync()
        {
            var jobs = await _jobService.GetJobsAsync();
            if (jobs == null || !jobs.Any()) return NotFound(ApiResponse<object>.Failed(null, "No jobs found", HttpContext.TraceIdentifier.ToString()));
            return Ok(ApiResponse<List<Job>>.Success(jobs, "", HttpContext.TraceIdentifier.ToString()));
        }
        [Authorize]
        [HttpGet("GetAlumniJobPostings")]
        public async Task<IActionResult> GetJobsAsync()
        {
            var Username = User.FindFirst("UserName")?.Value;
            var jobs = await _jobService.GetMyJobsAsync(Username);
            if (jobs == null || !jobs.Any()) return NotFound(ApiResponse<object>.Failed(null, "No jobs found", HttpContext.TraceIdentifier.ToString()));
            return Ok(ApiResponse<List<Job>>.Success(jobs, "", HttpContext.TraceIdentifier.ToString()));
        }
        [Authorize]
        [HttpDelete("DeleteJob/{jobId}")]
        public async Task<IActionResult> DeleteJobAsync(int jobId)
        {
            if (jobId <= 0) return BadRequest(ApiResponse<object>.Failed(null, "Invalid Job ID", HttpContext.TraceIdentifier.ToString()));
            var job = await _jobService.JobExistsbyidAsync(jobId);
            if (job == null) return NotFound(ApiResponse<object>.Failed(null, "Job not found", HttpContext.TraceIdentifier.ToString()));
            await _jobService.DeleteJobAsync(job);
            return Ok(ApiResponse<object>.Success(null, "Job deleted successfully", HttpContext.TraceIdentifier.ToString()));
        }
        [Authorize]
        [HttpPut("UpdateJob/{jobId}")]
        public async Task<IActionResult> UpdateJobAsync(int jobId,[FromBody] JobList updatedJob)
        {
            if (jobId <= 0 || updatedJob == null) return BadRequest(ApiResponse<object>.Failed(null, "Invalid input", HttpContext.TraceIdentifier.ToString()));
            var job = await _jobService.JobExistsbyidAsync(jobId);
            if (job == null) return NotFound(ApiResponse<object>.Failed(null, "No jobs found", HttpContext.TraceIdentifier.ToString()));
            
            return Ok(ApiResponse<object>.Success(null, "Job updated successfully", HttpContext.TraceIdentifier.ToString()));
        }
        
    }
}
