﻿using AlumniBackend.DATA;
using AlumniBackend.DTOs;
using AlumniBackend.Models;
using AlumniBackend.Services;
using AlumniBackend.Utilities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AlumniBackend.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EventController : ControllerBase
    {
        // Implementation for EventController goes here
        private readonly ILogger<EventController> _logger;
        private readonly AppDbContext _context;
        private readonly EventsService _eventsService;
        public EventController(AppDbContext context, EventsService eventsService)
        {
            _context = context;
            _eventsService = eventsService;

        }
        [Authorize]
        [HttpPost("CreateEvents")]
        public async Task<IActionResult> CreateEventsAsync(EventCreate ev)
        {
            if (ev == null) return BadRequest(ApiResponse<object>.Failed(null,"Invalid event data",HttpContext.TraceIdentifier.ToString()));
            var exists = await _eventsService.EventExistsAsync(ev.EventName);
            if (exists) return BadRequest(ApiResponse<object>.Failed(null, "Event already exists", HttpContext.TraceIdentifier.ToString()));
            var userNameClaim = User.FindFirst("UserName")?.Value;
            if (string.IsNullOrEmpty(userNameClaim)) return Unauthorized(ApiResponse<object>.Failed(null, "UserName missing in token", HttpContext.TraceIdentifier.ToString()));
            var result = await _eventsService.AddEventAsync(ev, userNameClaim);
            return Ok(ApiResponse<Events>.Success(result, "Event Created", HttpContext.TraceIdentifier.ToString()));
        }
        [Authorize] 
        [HttpGet("GetEvents")]
        
        public async Task<IActionResult> GetEvents(
        [FromQuery] DateTime? start,
        [FromQuery] DateTime? end)
        {
            start ??= DateTime.UtcNow.AddDays(-10);
            end ??= start.Value.AddMonths(1);

            var events = await _eventsService.GetEventsAsync(start.Value, end.Value);

            if (!events.Any())
                return NotFound(ApiResponse<object>.Failed(
                    null,
                    "No events found in the given date range",
                    HttpContext.TraceIdentifier
                ));

            return Ok(ApiResponse<List<Events>>.Success(
                events,
                "Events fetched successfully",
                HttpContext.TraceIdentifier
            ));
        }

        [Authorize]
        [HttpDelete("DeleteEvent/{eventId}")]
        public async Task<IActionResult> DeleteEventAsnyc(int eventId)
        {
            if (eventId <= 0) return BadRequest(ApiResponse<object>.Failed(null, "Invalid Event ID", HttpContext.TraceIdentifier.ToString()));
            var eventEntity = await _eventsService.EventExistsAsync(eventId);
            if (eventEntity) return NotFound(ApiResponse<object>.Failed(null, "Event not found", HttpContext.TraceIdentifier.ToString()));
            var result = await _eventsService.DeleteEventsAsync(eventId);
            if (!result) return StatusCode(500, ApiResponse<object>.Failed(null, "Failed to delete event", HttpContext.TraceIdentifier.ToString()));
            return Ok(ApiResponse<object>.Success(null, "Event deleted successfully", HttpContext.TraceIdentifier.ToString()));
        }
        [Authorize]
        [HttpPut("UpdateEvent/{eventId}")]
        public async Task<IActionResult> UpdateEventAsync(int eventId, EventCreate ev)
        {
            if (eventId <= 0 || ev == null) return BadRequest(ApiResponse<object>.Failed(null, "Invalid input", HttpContext.TraceIdentifier.ToString()));
            var eventEntity = await _eventsService.EventExistsAsync(eventId);
            if (!eventEntity) return NotFound(ApiResponse<object>.Failed(null, "Event not found", HttpContext.TraceIdentifier.ToString()));
            var result = await _eventsService.UpdateEventAsync(eventId, ev);
            return Ok(ApiResponse<Events>.Success(result, "Event updated successfully", HttpContext.TraceIdentifier.ToString()));
        }
        
    }
}
