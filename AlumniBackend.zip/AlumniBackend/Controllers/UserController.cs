﻿using AlumniBackend.DATA;
using AlumniBackend.DTOs;
using AlumniBackend.Models;
using AlumniBackend.Services;
using AlumniBackend.Utilities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using static AlumniBackend.DTOs.RoleElevation;
using static AlumniBackend.Models.User;

namespace AlumniBackend.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UserController:ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly UserService _user;
        public UserController(AppDbContext context, UserService userService)
        {
            _context = context; 
            _user = userService;
        }
        //admin creates user's creds and then seds the base creds
        [HttpPost("CreateUser")]
        public async Task<IActionResult> CreateUser([FromBody] UserCreation user )
        {
            if(user == null ) return BadRequest(ApiResponse<object>.Failed(null, "User missing", HttpContext.TraceIdentifier.ToString()));

            var password = user.Passwordhash;
            var passhashed = BCrypt.Net.BCrypt.EnhancedHashPassword(password);
            var User = new User
            {
                UserName = user.UserName,
                Email = user.Email,
                Phone = user.Phone,
                Passwordhash = passhashed               
            };
            await _user.userAddAsync(User);
            return Ok(ApiResponse<object>.Success(null, "User Creation Successful", HttpContext.TraceIdentifier.ToString()));
        }
        //admin does 
        [HttpPatch("ElevateRole")]
        public async Task<IActionResult> ElevateRoles([FromBody] RoleElevation re)
        {
            var result = await _user.RoleUpdateAsync(re);
            if (!result) return BadRequest(ApiResponse<object>.Failed(null, "Invalid", HttpContext.TraceIdentifier.ToString()));
            return Ok(ApiResponse<object>.Success(null, "user updated", HttpContext.TraceIdentifier.ToString()));
        }
        //admin 
        [Authorize(Roles = "Admin")]
        [HttpGet("GetUser")]
        public async Task<IActionResult> GetUser(string Username)
        {
            var user = await _user.GetUserByUsernameAsync(Username);
            if (user == null) return BadRequest(ApiResponse<object>.Failed(null, "User Details not found", HttpContext.TraceIdentifier.ToString()));
            return Ok(user);
        }
        [Authorize]
        [HttpPost("UpdatePassword")]
        public async Task<IActionResult> UpdatePassword([FromBody] Userpass user)
        {
            if (string.IsNullOrEmpty(user.username)) return BadRequest(ApiResponse<object>.Failed(null, "Username missing", HttpContext.TraceIdentifier.ToString()));
            var dbUser = await _user.GetUserByUsernameAsync(user.username); 
            if (dbUser == null) return BadRequest(ApiResponse<object>.Failed(null, "User not found", HttpContext.TraceIdentifier.ToString()));
            var newpass = BCrypt.Net.BCrypt.EnhancedHashPassword(user.password);
            dbUser.Passwordhash = newpass;
            await _user.SaveAsync();
            return Ok(ApiResponse<object>.Success(null, "Password Updated", HttpContext.TraceIdentifier.ToString()));
        }
        public class Userpass()
        {
            public string username { get; set; }
            public string password { get; set; }
        }
        [Authorize]
        [HttpPost("CreatePasswordOnLogin")]
        public async Task<IActionResult> CreatePasswordOnLogin([FromBody] string pass)
        {
            var userNameClaim = User.FindFirst("UserName")?.Value;
            if (string.IsNullOrEmpty(userNameClaim)) return Unauthorized(ApiResponse<object>.Failed(null, "UserName missing in token", HttpContext.TraceIdentifier.ToString()));
            var dbUser = await _user.GetUserByUsernameAsync(userNameClaim);
            if(dbUser == null) return BadRequest(ApiResponse<object>.Failed(null, "User not found", HttpContext.TraceIdentifier.ToString()));
            dbUser.IsFirstLogin = false;
            dbUser.Passwordhash = BCrypt.Net.BCrypt.EnhancedHashPassword(pass);
            await _user.SaveAsync();

            return Ok(ApiResponse<object>.Success(null, "Password Created Successfully", HttpContext.TraceIdentifier.ToString()));
        }
    }
}
