﻿using AlumniBackend.DATA;
using AlumniBackend.Models;
using AlumniBackend.Services;
using AlumniBackend.Utilities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AlumniBackend.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class MentorshipRequestController: ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly MentorshipService _mentorshipService;
        public MentorshipRequestController(AppDbContext context, MentorshipService mentorshipService)
        {
            _context = context;
            _mentorshipService = mentorshipService;
        }
        [Authorize]
        [HttpGet]
        public async Task<IActionResult> CreateMentorshipRequests(int alumniid)
        {   
            var username = User.FindFirst("UserName")?.Value;
            if (string.IsNullOrEmpty(username))
                return Unauthorized("UserName missing in token");

            // Fetch the user ID from the database
            var userId = await _mentorshipService.GetUserIDAsync(username);
            if (userId == 0)
                return NotFound("User not found");

            // Create mentorship request entity
            var mentorshipRequest = new MentorshipRequest
            {
                UserId = userId,
                AlumniId = alumniid
            };

            // Add to DB
            await _mentorshipService.AddAsync(mentorshipRequest);
           

            return Ok(ApiResponse<object>.Success(null,"Mentorship request created successfully!", HttpContext.TraceIdentifier.ToString()));
        }
        [Authorize(Roles = "Alumni")]
        [HttpGet("GetMentorshipRequests")]
        public async Task<IActionResult> GetMentorshipRequests()
        {
            var username = User.FindFirst("UserName")?.Value;
            if (string.IsNullOrEmpty(username))
                return Unauthorized(ApiResponse<object>.Failed(null, "UserName missing in token", HttpContext.TraceIdentifier.ToString()));
            var mentorshipRequests = await _mentorshipService.GetMentorshipRequestsByAlumniIdAsync(username);
            if (mentorshipRequests == null || !mentorshipRequests.Any())
                return NotFound(ApiResponse<object>.Failed(null, "No mentorship requests found", HttpContext.TraceIdentifier.ToString()));
            return Ok(mentorshipRequests);
        }
        [Authorize(Roles = "Alumni")]
        [HttpPost("Approve/Reject MentorshipRequest")]
        public async Task<IActionResult> ApproveMentorshipRequest(int requestId, MentorshipRequest.status status)
        {
            var mentorshipRequest = await _mentorshipService.MentorshipRequestExistsAsync(requestId);
            if (mentorshipRequest == null)
                return NotFound(ApiResponse<object>.Failed(null, "Mentorship request not found", HttpContext.TraceIdentifier.ToString()));
            mentorshipRequest.Status = status;
            await _mentorshipService.UpdateAsync(mentorshipRequest);
            
            return Ok(ApiResponse<object>.Success(null, "Mentorship request status updated successfully!", HttpContext.TraceIdentifier.ToString()));
        }
        [Authorize]
        [HttpPost("AskMentorshipToAll")]
        public async Task<IActionResult> AskMentorshipToAll()
        {
            var username = User.FindFirst("UserName")?.Value;
            if (string.IsNullOrEmpty(username))
                return Unauthorized(ApiResponse<object>.Failed(null, "UserName missing in token", HttpContext.TraceIdentifier.ToString()));

            var mentorshiRequests = new MentorshipRequest
            {
                UserId = await _mentorshipService.GetUserIDAsync(username)
            };
            await _mentorshipService.AddAsync(mentorshiRequests);
            return Ok(ApiResponse<object>.Success(null, "Mentorship request created successfully!", HttpContext.TraceIdentifier.ToString()) );
        }
        [Authorize]
        [HttpGet("MentorshipRequestsDashboards")]
        public async Task<IActionResult> MentorshipRequestsDashboards()
        {
            var dashboardData = await _mentorshipService.GetDashboardDataAsync();
            return Ok(ApiResponse<object>.Success(dashboardData, "Mentorship requests dashboard data retrieved successfully", HttpContext.TraceIdentifier.ToString()));
        }
        [Authorize]
        [HttpPost("AcceptOpenRequest")]
        public async Task<IActionResult> AcceptOpenRequestAsync(int requestId)
        {
            var username = User.FindFirst("UserName")?.Value;
            if (string.IsNullOrEmpty(username))
                return Unauthorized(ApiResponse<object>.Failed(null, "UserName missing in token", HttpContext.TraceIdentifier.ToString()));
            var alumniId = await _mentorshipService.GetUserIDAsync(username);
            var mentorshipRequest = await _mentorshipService.MentorshipRequestExistsAsync(requestId);
            if (mentorshipRequest == null)
                return NotFound(ApiResponse<object>.Failed(null, "Mentorship request not found", HttpContext.TraceIdentifier.ToString()));
            mentorshipRequest.AlumniId = alumniId;
            await _mentorshipService.UpdateAsync(mentorshipRequest);
            return Ok(ApiResponse<object>.Success(null, "Mentorship request accepted successfully!", HttpContext.TraceIdentifier.ToString()));
        }
    }
}

