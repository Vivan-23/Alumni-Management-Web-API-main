﻿using AlumniBackend.DATA;
using AlumniBackend.DTOs;
using AlumniBackend.Models;
using AlumniBackend.Services;
using AlumniBackend.Utilities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AlumniBackend.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DonationsController: ControllerBase
    {
        private readonly ILogger<DonationsController> _logger;
        private readonly IConfiguration _configuration;
        private readonly AppDbContext _context;
        private readonly DonationsService _donation;
        public DonationsController(AppDbContext context, DonationsService donation)
        {
            _context = context;
            _donation = donation;
        }
        [Authorize]
        [HttpGet("GetDonations")]
        public async Task<IActionResult> GetDonationsAsync()
        {
            var donations = await _donation.GetDonationsAsync();
            if (donations == null || !donations.Any()) return NotFound(ApiResponse<object>.Failed(null, "No donations found", HttpContext.TraceIdentifier.ToString()));
            return Ok(ApiResponse<List<Donation>>.Success(donations, "", HttpContext.TraceIdentifier.ToString()));
        }
        //[Authorize] 
        //[HttpPost("Create Donation")]
        //public async Task<IActionResult> CreateDonation(DonationCreation donation)
        //{
        //    var username = User.FindFirst("Username")?.Value;
        //    var userid = await _context.Donations.FirstOrDefaultAsync(username);
        //    var value = new Donation
        //    {
        //        UserId = username,

        //    }


        //}

        //[Authorize]
        //[HttpPost("Donate")]
        //public async Task<IActionResult> Donate(int DonationId)
        //{
        //    var user = User.FindFirst("Username")?.Value;

        //}
    }
}
