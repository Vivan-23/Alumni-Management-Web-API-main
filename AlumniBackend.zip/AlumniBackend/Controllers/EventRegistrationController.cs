﻿using AlumniBackend.DATA;
using AlumniBackend.Models;
using AlumniBackend.Services;
using AlumniBackend.Utilities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using static AlumniBackend.Models.EventRegistration;

namespace AlumniBackend.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EventRegistrationController : ControllerBase
    {
        private readonly ILogger<EventRegistrationController> _logger;
        private readonly AppDbContext _context;
        private readonly EventsRegistrationService _eventsRegistrationService;
        public EventRegistrationController(AppDbContext context , EventsRegistrationService eventsRegistrationService)
        {
            _context = context;
            _eventsRegistrationService = eventsRegistrationService;
        }
        [Authorize]
        [HttpPost("Registerforevent")]
        public async Task<IActionResult> RegisterForEvent(int eventid)
        {
            var userNameClaim = User.FindFirst("UserName")?.Value;

            if (string.IsNullOrEmpty(userNameClaim))
                return Unauthorized(ApiResponse<object>.Failed(
                    null,
                    "UserName missing in token",
                    HttpContext.TraceIdentifier
                ));

            int? alumniId = await _eventsRegistrationService.GetAlumniIdAsync(userNameClaim);

            if (alumniId == null)
                return NotFound(ApiResponse<object>.Failed(
                    null,
                    "Alumni profile not found",
                    HttpContext.TraceIdentifier
                ));

            bool eventExists = await _eventsRegistrationService.EventExists(eventid);
            if (!eventExists)
                return NotFound(ApiResponse<object>.Failed(
                    null,
                    "No Event Found",
                    HttpContext.TraceIdentifier
                ));

            bool alreadyRegistered =
                await _eventsRegistrationService.IsRegisteredAsync(eventid, alumniId.Value);

            if (alreadyRegistered)
                return BadRequest(ApiResponse<object>.Failed(
                    null,
                    "User already registered for this event",
                    HttpContext.TraceIdentifier
                ));

            var registration = new EventRegistration
            {
                EventId = eventid,
                AlumniId = alumniId.Value,   // ✅ SAFE
                Status = status.yes
            };

            bool result =
                await _eventsRegistrationService.RegisterationAsync(eventid, registration);

            if (!result)
                return BadRequest(ApiResponse<object>.Failed(
                    null,
                    "Event registration is closed",
                    HttpContext.TraceIdentifier
                ));

            return Ok(ApiResponse<object>.Success(
                null,
                "Event registered successfully",
                HttpContext.TraceIdentifier
            ));
        }

        //public async Task<IActionResult> RegisterForEvent(int eventid)
        //{
        //    var userNameClaim = User.FindFirst("UserName")?.Value;
        //    var aluid = await _eventsRegistrationService.GetAlumniIdAsync(userNameClaim);

        //    if (aluid == 0)
        //        return NotFound(ApiResponse<object>.Failed(
        //            null,
        //            "Alumni profile not found",
        //            HttpContext.TraceIdentifier
        //        ));

        //    var Event = await _eventsRegistrationService.EventExists(eventid);

        //    if (!Event) return NotFound(ApiResponse<object>.Failed(null, "No Event Found", HttpContext.TraceIdentifier.ToString()));
        //    if (string.IsNullOrEmpty(userNameClaim)) return Unauthorized("UserName missing in token");

        //    var alreadyRegistered = await _eventsRegistrationService.IsRegisteredAsync(eventid, aluid);
        //    if (alreadyRegistered) return BadRequest("User already registered for this event");
        //    var registration = new Models.EventRegistration
        //    {
        //        EventId = eventid,
        //        AlumniId = aluid,
        //        Status = status.yes
        //    };
        //    var result = await _eventsRegistrationService.RegisterationAsync(eventid, registration);
        //    if (!result) return BadRequest(ApiResponse<object>.Failed(null, "Event registration is closed", HttpContext.TraceIdentifier.ToString()));

        //    return Ok(ApiResponse<object>.Success(null, "Event Registration Controller", HttpContext.TraceIdentifier.ToString()));
        //}
        [Authorize(Roles = "Admin")]
        [HttpGet("GetAllRegistrations")]
        public async Task<IActionResult> GetAllEventRegistrations()
        {
            var registrations = await _eventsRegistrationService.GetEventRegistrationsAsync();
            if (registrations == null || registrations.Count == 0)
            {
                return NotFound(ApiResponse<object>.Failed(null, "No registrations found for this event", HttpContext.TraceIdentifier.ToString()));
            }
            return Ok(ApiResponse<List<EventRegistration>>.Success(registrations,"Successfully", HttpContext.TraceIdentifier.ToString()));
        }
        //only show's user's created events
        [Authorize]
        [HttpPost("GetUserEvents")]
        public async Task<IActionResult> GetEventRegistrations()
        {
            var username = User.FindFirst("Username")?.Value;
            var registrations = await _eventsRegistrationService.GetUsersEventRegistrationsAsync(username);
            if (registrations == null || registrations.Count == 0)
            {
                return NotFound(ApiResponse<object>.Failed(null, "No registrations found for this event", HttpContext.TraceIdentifier.ToString()));
            }
            return Ok(ApiResponse<List<EventRegistration>>.Success(registrations, "Successfully", HttpContext.TraceIdentifier.ToString()));
        }
        [Authorize]
        [HttpDelete("Delete Registration")]
        public async Task<IActionResult> CancelRegistration(int eventid)
        {
            var userNameClaim = User.FindFirst("UserName")?.Value;
            var alu = await _eventsRegistrationService.GetAlumniAsync(userNameClaim);
            int aluid = await _eventsRegistrationService.GetAlumniIdAsync(userNameClaim);
            if (aluid == 0)
                {
                return NotFound(ApiResponse<object>.Failed(null, "Alumni profile not found", HttpContext.TraceIdentifier.ToString()));
            }
            var registration = await _eventsRegistrationService.GetRegistrationAsync(eventid, aluid);
            if (registration == null)
            {
                return NotFound(ApiResponse<object>.Failed(null, "Registration not found", HttpContext.TraceIdentifier.ToString()));
            }
            await _eventsRegistrationService.CancelRegistrationAsync(registration);
            
            return Ok(ApiResponse<object>.Success(null, "Registration cancelled successfully", HttpContext.TraceIdentifier.ToString()));
        }
    }
}

