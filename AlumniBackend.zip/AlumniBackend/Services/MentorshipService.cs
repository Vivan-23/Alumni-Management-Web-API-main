﻿using AlumniBackend.DATA;
using AlumniBackend.Models;
using Microsoft.EntityFrameworkCore;

namespace AlumniBackend.Services
{
    public class MentorshipService
    {
        private readonly AppDbContext _context;
        public MentorshipService(AppDbContext context)
        {
            _context = context;
        }
        public async Task<int> GetUserIDAsync(string username)
        {
            var userId = await _context.Users
                .Where(u => u.UserName == username)
                .Select(u => u.UserId)
                .FirstOrDefaultAsync();
            return userId;
        }
        public async Task AddAsync(MentorshipRequest mentorshipRequest)
        {
            await _context.MentorshipRequests.AddAsync(mentorshipRequest);
            await _context.SaveChangesAsync();
        }
        public async Task<object> GetDashboardDataAsync()
        {
            var totalRequests = await _context.MentorshipRequests.CountAsync();
            var pendingRequests = await _context.MentorshipRequests.CountAsync(m => m.Status == MentorshipRequest.status.Pending);
            var approvedRequests = await _context.MentorshipRequests.CountAsync(m => m.Status == MentorshipRequest.status.Approved);
            var rejectedRequests = await _context.MentorshipRequests.CountAsync(m => m.Status == MentorshipRequest.status.Not_Approved);
            var openRequests = await _context.MentorshipRequests.CountAsync(m => m.AlumniId == null);
            var dashboardData = new
            {
                TotalRequests = totalRequests,
                PendingRequests = pendingRequests,
                ApprovedRequests = approvedRequests,
                RejectedRequests = rejectedRequests,
                OpenRequests = openRequests
            };
            return dashboardData;
        }
        public async Task<List<MentorshipRequest>> GetMentorshipRequestsByAlumniIdAsync(string username)
        {
            var id = await _context.AlumniProfiles.Where(a => a.User.UserName == username)
                .Select(a => a.AlumniId)
                .FirstOrDefaultAsync();
            return (_context.MentorshipRequests.Where(m => m.AlumniId == id).ToList());
        }
        public async Task<MentorshipRequest> MentorshipRequestExistsAsync(int requestId)
        {
            var MENTOR =  await _context.MentorshipRequests.FirstOrDefaultAsync(m => m.RequestId == requestId);
            return MENTOR;  
        }
        public async Task UpdateAsync(MentorshipRequest mentorshipRequest)
        {
            _context.MentorshipRequests.Update(mentorshipRequest);
            await _context.SaveChangesAsync();
        }
    }
}
