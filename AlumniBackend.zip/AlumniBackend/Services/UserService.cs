﻿using AlumniBackend.DATA;
using AlumniBackend.DTOs;
using AlumniBackend.Models;
using AlumniBackend.Utilities;
using Microsoft.EntityFrameworkCore;

namespace AlumniBackend.Services
{
    public class UserService
    {
        private readonly AppDbContext _context;
        public UserService(AppDbContext context) 
        {
            _context = context;
        }
        public async Task<bool> UserExistsAsync(string username)
        {
            return await _context.Users.AnyAsync(u => u.UserName == username);
        }
        public async Task userAddAsync(User user)
        {
            await _context.Users.AddAsync(user);
            await _context.SaveChangesAsync();
        }
        public async Task<bool> RoleUpdateAsync(RoleElevation re)
        {
            var user = await _context.Users.FirstOrDefaultAsync(s => s.UserName == re.UserName);
            if (user == null) return false;
            var newrole = await _context.Roles.FirstOrDefaultAsync(s => s.RoleName == re.Role);
            if (newrole.RoleName == null) return false;

            user.Role = newrole;
            await _context.SaveChangesAsync();
            return true;
        }
        public async Task SaveAsync()
        {
            await _context.SaveChangesAsync();
        }
        public async Task<User> GetUserByUsernameAsync(string username)
        {
            return await _context.Users.FirstOrDefaultAsync(u => u.UserName == username);
        }
    }
}
