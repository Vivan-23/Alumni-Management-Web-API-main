﻿using AlumniBackend.DATA;
using AlumniBackend.DTOs;
using AlumniBackend.Models;
using AlumniBackend.Utilities;
using Microsoft.EntityFrameworkCore;

namespace AlumniBackend.Services
{
    public class AlumniProfileService
    {
        private readonly AppDbContext _context;
        public AlumniProfileService(AppDbContext context)
        {
            _context = context;
        }
        public async Task<AlumniProfileUpdate> UpdateProfileAsync(AlumniProfileUpdate info, string userName)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.UserName == userName);
            if (user == null) return null;

            var existing = await _context.AlumniProfiles.FirstOrDefaultAsync(a => a.UserId == user.UserId);

            if (existing == null)
            {
                var profile = new AlumniProfile
                {
                    AlumniName = info.AlumniName,
                    CompanyName = info.CompanyName,
                    Designation = info.Designation,
                    linkedinurl = info.linkedinurl,
                    Passout_year = info.Passout_year,
                    UserId = (int)user.UserId
                };
                await _context.AlumniProfiles.AddAsync(profile);
            }
            else
            {
                existing.AlumniName = info.AlumniName;
                existing.CompanyName = info.CompanyName;
                existing.Designation = info.Designation;
                existing.linkedinurl = info.linkedinurl;
                existing.Passout_year = info.Passout_year;
            }

            await _context.SaveChangesAsync();
            return info;
        }
        public async Task<object> AlumniinfoAync(string username)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.UserName == username);
            if (user == null) return null;

            var alum = await _context.AlumniProfiles.FirstOrDefaultAsync(s => s.UserId == user.UserId);
            if (alum == null) return null;

            var result = new
            {
                user.UserName,
                user.Email,
                user.Phone,
                alum.AlumniName,
                alum.CompanyName,
                alum.Designation,
                alum.Passout_year,
                alum.linkedinurl
            };
            return result;
        }
    }

}
