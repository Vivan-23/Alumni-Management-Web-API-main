﻿using AlumniBackend.DATA;
using AlumniBackend.DTOs;
using AlumniBackend.Models;
using Microsoft.EntityFrameworkCore;

namespace AlumniBackend.Services
{
    public class EventsService
    {
        private readonly AppDbContext _context;
        public EventsService(AppDbContext context)
        {
            _context = context;
        }
        public async Task<bool> EventExistsAsync(string eventName)
        {
            return await _context.Events.AnyAsync(e => e.EventName == eventName);
        }
        public async Task<bool> EventExistsAsync(int eventid)
        {
            return await _context.Events.AnyAsync(e => e.EventsId == eventid);
        }
        public async Task<bool> EventExistswithinAsync(DateTime start, DateTime end)
        {
            return await _context.Events.AnyAsync(e => e.EventDate >= DateOnly.FromDateTime(start) && e.EventDate <= DateOnly.FromDateTime(end));
        }
        public async Task<Events> AddEventAsync(EventCreate ev, string userNameClaim)
        {
            var Event = new Events
            {
                EventName = ev.EventName,
                EventDescription = ev.EventDescription,
                EventTime = ev.EventTime,
                EventDate = ev.EventDate,
                EventLocation = ev.EventLocation,
                CreatedBy = userNameClaim
            };
            await _context.Events.AddAsync(Event);
            await _context.SaveChangesAsync();
            return Event;
        }
        public async Task<List<Events>> GetEventsAsync(DateTime start, DateTime end)
        {
            return await _context.Events
                .Where(e => e.EventDate >= DateOnly.FromDateTime(start) && e.EventDate <= DateOnly.FromDateTime(end))
                .ToListAsync();
        }   
        public async Task<bool> DeleteEventsAsync(int eventId)
        {
            var eventEntity = await _context.Events.FindAsync(eventId);
            if (eventEntity == null) return false;
            _context.Events.Remove(eventEntity);
            await _context.SaveChangesAsync();
            return true;
        }
        public async Task<Events> UpdateEventAsync(int eventId, EventCreate ev)
        {
            var eventEntity = await _context.Events.FindAsync(eventId);
            if (eventEntity == null) return null;
            eventEntity.EventName = ev.EventName;
            eventEntity.EventDescription = ev.EventDescription;
            eventEntity.EventTime = ev.EventTime;
            eventEntity.EventDate = ev.EventDate;
            eventEntity.EventLocation = ev.EventLocation;
            _context.Events.Update(eventEntity);
            await _context.SaveChangesAsync();
            return eventEntity;
        }
    }
}
