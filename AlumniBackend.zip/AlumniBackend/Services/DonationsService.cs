﻿using AlumniBackend.DATA;
using AlumniBackend.Models;
using Microsoft.EntityFrameworkCore;

namespace AlumniBackend.Services
{
    public class DonationsService
    {
        private readonly AppDbContext _context;
        public DonationsService(AppDbContext context)
        {
            _context = context;
        }
        public async Task<List<Donation>> GetDonationsAsync()
        {
            return await _context.Donations.ToListAsync();
        }
    }
}
