﻿using AlumniBackend.DATA;
using AlumniBackend.Models;
using Microsoft.EntityFrameworkCore;

namespace AlumniBackend.Services
{
    public class JobService
    {
        private readonly AppDbContext _context;
        public JobService(AppDbContext context)
        {
            _context = context;
        }
        public async Task<bool> JobExistsAsync(string title, string company)
        {
            return await _context.Job.AnyAsync(j => j.Title == title && j.Company == company);
        }
        public async Task<Job> JobExistsbyidAsync(int id)
        {
            return await _context.Job.FirstOrDefaultAsync(j => j.JobId== id);
        }
        public async Task AddJobAsync(Job job)
        {
            await _context.Job.AddAsync(job);
            await _context.SaveChangesAsync();
        }
        public async Task<List<Job>> GetJobsAsync()
        {
            return await _context.Job
                .Include(j => j.Alumni)
                .Where(j => j.ExpiryDate == null || j.ExpiryDate > DateTime.Now)
                .ToListAsync();
        }
        public async Task<List<Job>> GetMyJobsAsync(string username)
        {
            return await _context.Job
                .Include(j => j.Alumni)
                .Where(j => j.Alumni.AlumniName == username)
                .Where(j => j.ExpiryDate == null || j.ExpiryDate > DateTime.Now)
                .ToListAsync();
        }
        public async Task DeleteJobAsync(Job job)
        {
            _context.Job.Remove(job);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateJobAsync(Job job)
        {
            _context.Job.Update(job);
            await _context.SaveChangesAsync();
        }
        public async Task<List<Job>> GetJobsByAlumniIdAsync(int alumniId)
        {
            return await _context.Job
                .Where(j => j.AlumniId == alumniId && (j.ExpiryDate == null || j.ExpiryDate > DateTime.Now))
                .ToListAsync();
        }

    }
}
