﻿using AlumniBackend.DATA;
using AlumniBackend.Models;
using AlumniBackend.Utilities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;

namespace AlumniBackend.Services
{
    public class EventsRegistrationService
    {
        private readonly AppDbContext _context;
        public EventsRegistrationService(AppDbContext context)
        {
            _context = context;
        }
        public async Task<bool> EventExists(int eventId)
        {
            return await _context.Events.AnyAsync(e => e.EventsId == eventId);
        }
        public async Task<bool> RegisterationAsync(int eventId, EventRegistration ev)
        {
            var Event = await _context.Events
                .FirstOrDefaultAsync(e => e.EventsId == eventId);

            if (Event == null)
                return false;

            if (Event.EventDate < DateOnly.FromDateTime(DateTime.UtcNow))
                return false;
            if (ev.AlumniId <= 0)
                throw new InvalidOperationException("Invalid AlumniId");

            await _context.EventRegistrations.AddAsync(ev);
            await _context.SaveChangesAsync();

            return true;
        }

        public async Task<EventRegistration> GetRegistrationAsync(int eventId, int alumniId)
        {
            return await _context.EventRegistrations
                .FirstOrDefaultAsync(er => er.EventId == eventId && er.AlumniId == alumniId);
        }
        public async Task<int> GetAlumniIdAsync(string username)
        {
            if (string.IsNullOrEmpty(username))
                return 0;

            var alumni = await _context.AlumniProfiles
                .Include(a => a.User)
                .FirstOrDefaultAsync(a => a.User.UserName == username);

            if (alumni != null)
                return alumni.AlumniId;

            return 0; // ❗ no alumni profile exists
        }

        public async Task<AlumniProfile> GetAlumniAsync(string username)
        {
            var alu = await _context.AlumniProfiles.FirstOrDefaultAsync(s => s.AlumniName == username);
            int aluid = alu.AlumniId;
            if (alu == null)
            {
                var stu = await _context.Users.FindAsync(username);
                aluid = (int)stu.UserId;
            }
            return alu;
        }
        public async Task<bool> IsRegisteredAsync(int eventId, int alumniId)
        {
            return await _context.EventRegistrations.AnyAsync(er => er.EventId == eventId && er.AlumniId == alumniId);
        }
        public async Task<List<EventRegistration>> GetEventRegistrationsAsync()
        {
            return await _context.EventRegistrations
                .ToListAsync();
        }
        public async Task<List<EventRegistration>> GetUsersEventRegistrationsAsync(string username)
        {
            return await _context.EventRegistrations
                .ToListAsync();
        }
        public async Task CancelRegistrationAsync(EventRegistration registration)
        {
            
            _context.EventRegistrations.Remove(registration);
            await _context.SaveChangesAsync();
            
        }
    }
}
    